This program has been written by Cody Fulford for CPSC 411 at the University of Calgary in the Winter 2017 Semester.

To run this code, simply go into the src folder, open a command prompt and type "main <filepath>" if on Windows or "./main <filepath>" if on linux
IF you run the code on windows, i have creaetd some batch files designed to speed the testing process


This code will generate the AST of the provided code and show it in the commmand prompt

The pretty parsing library that i have used is GenericPretty

Limitations:
The limitations of this code are as follows:

No support for error checking,
No conversion to stack code,
No saving the stack code to a file